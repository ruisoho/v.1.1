Ninja htm https://www.youtube.com/watch?v=Y1BlT4_c_SU&list=PL4cUxeGkcC9ibZ2TSBaGGNrgh4ZgYE6Cc
Ninja css https://www.youtube.com/watch?v=I9XRrlOOazo&list=PL4cUxeGkcC9gQeDH6xYhmO-db2mhoTSrT
Ninja responsive https://www.youtube.com/watch?v=3tLb3i7GB38&list=PL4cUxeGkcC9g9Vh9MAA-XKnfJsWZnPZFw
Ninja Matrialize https://www.youtube.com/watch?v=gCZ3y6mQpW0&list=PL4cUxeGkcC9gGrbtvASEZSlFEYBnPkmff
Bootstrap 3 https://www.youtube.com/watch?v=xvfm7IpEkBk&list=PL4cUxeGkcC9g_69kOfXICzT_hZ79_td99
Bootstrap 4 https://www.youtube.com/watch?v=QAgrHLtG1Yk&list=PL4cUxeGkcC9jE_cGvLLC60C_PeF_24pvv
jQuery https://www.youtube.com/watch?v=jVe1GBCqFIE&list=PL4cUxeGkcC9hNUJ0j6ccnOAcJIPoTRpO4
JS https://www.youtube.com/watch?v=qoSksQ4s_hg&list=PL4cUxeGkcC9i9Ae2D9Ee1RvylH38dKuET
JSES6 https://www.youtube.com/watch?v=0Mp2kwE8xY0&list=PL4cUxeGkcC9gKfw25slm4CUDUcM_sXdml
Modern JS https://www.youtube.com/watch?v=iWOYAxlnaww&list=PL4cUxeGkcC9haFPT7J25Q9GRB_ZkFrQAc
AgularJS https://www.youtube.com/watch?v=FlUCU13dJyo&list=PL4cUxeGkcC9gsJS5QgFT2IvWIX78dV3_v
React https://www.youtube.com/watch?v=yZ0f1Apb5CU&list=PL4cUxeGkcC9i0_2FF-WhtRIfIJ1lXlTZR
Vue https://www.youtube.com/watch?v=5LYrN_cAJoA&list=PL4cUxeGkcC9gQcYgjhBoeQH7wiAyZNrYa

Traversy Media:
Htlm https://www.youtube.com/watch?v=UB1O30fR-EE&list=PLillGF-RfqbZTASqIqdvm1R5mLrQq79CU&index=1
CSS https://www.youtube.com/watch?v=yfoY53QXEnI&list=PLillGF-RfqbZTASqIqdvm1R5mLrQq79CU&index=2
HTML 5 Responsive https://www.youtube.com/watch?v=UB1O30fR-EE&list=PLillGF-RfqbZTASqIqdvm1R5mLrQq79CU
Flexbox CSS https://www.youtube.com/watch?v=JJSoEo8JSnc&list=PLillGF-RfqbZTASqIqdvm1R5mLrQq79CU&index=4
CSS GRID Layout https://www.youtube.com/watch?v=jV8B24rSN5o&list=PLillGF-RfqbZTASqIqdvm1R5mLrQq79CU&index=5
Bootstrap https://www.youtube.com/watch?v=5GcQtLDGXy8&list=PLillGF-RfqbZTASqIqdvm1R5mLrQq79CU&index=16
Materialize PT1 https://www.youtube.com/watch?v=nqT8c5OFjEQ&list=PLillGF-RfqbZTASqIqdvm1R5mLrQq79CU&index=27
Materialize PT2  https://www.youtube.com/watch?v=ZpduVPHZ5Aw&list=PLillGF-RfqbZTASqIqdvm1R5mLrQq79CU&index=28
Vanilla JS https://www.youtube.com/watch?v=hdI2bqOjy3c&list=PLillGF-RfqbbnEGy3ROiLWk7JMCuSyQtX&index=1
JS DOM PT1 -https://www.youtube.com/watch?v=0ik6X4DJKCc&list=PLillGF-RfqbbnEGy3ROiLWk7JMCuSyQtX&index=2
JS DOM PT2 - https://www.youtube.com/watch?v=mPd2aJXCZ2g&list=PLillGF-RfqbbnEGy3ROiLWk7JMCuSyQtX&index=3
JS DOM PT3 - https://www.youtube.com/watch?v=wK2cBMcDTss&list=PLillGF-RfqbbnEGy3ROiLWk7JMCuSyQtX&index=4
JS DOM PT4 - https://www.youtube.com/watch?v=i37KVt_IcXw&list=PLillGF-RfqbbnEGy3ROiLWk7JMCuSyQtX&index=5
GO PRO (Freelancing as a Web Developer) https://www.youtube.com/watch?v=m2N3tmJ_A0Q&list=PLillGF-RfqbZ_hV3gQav81bUCpCANWXOu&index=11

Mosh:
React - https://www.youtube.com/watch?v=Ke90Tje7VS0
SQL - https://www.youtube.com/watch?v=7S_tz1z_5bA
Pyton for programmers - https://www.youtube.com/watch?v=f79MRyMsjrQ
C# - https://www.youtube.com/watch?v=gfkTfcpWqAY
Angular - https://www.youtube.com/watch?v=k5E2AVpwsko 