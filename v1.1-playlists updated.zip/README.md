# undercode.org

Undercode is a platform for developers and designers alike (more like a community), committed to providing resources (free of cost) to new developers/designers. 

The undercode project is an open-sourced one, open to all developers who wish to contribute and help grow the technology ecosystem. 

# NB:
While this project is open-source, anyone can contribute as long as you have an intermediate knowledge of programming. 
Welcome to the undercode team!

The undercode team ☕
